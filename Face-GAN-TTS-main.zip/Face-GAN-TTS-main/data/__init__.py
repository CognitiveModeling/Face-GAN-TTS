from .lrs2_dataset import lrs2Dataset
from .lrs2_datamodule import lrs2DataModule

_datamodules = {
    "dataset_lrs2": lrs2DataModule,
}
